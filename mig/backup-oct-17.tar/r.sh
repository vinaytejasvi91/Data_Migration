sh /home/d88167i/mig/com/telstra/bi2020/script/run.sh
